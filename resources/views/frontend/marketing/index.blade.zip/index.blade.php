@extends('frontend.marketing.master')
@section('section')


	<!-- Master Slider -->
	<div class="blog-ms-v1 content-sm bg-color-darker margin-bottom-60">
		<div class="master-slider ms-skin-default" id="masterslider">
			@foreach($slider as $row)
			<div class="ms-slide blog-slider">
				<img src="{{asset('public/uploads/Slider/'.$row->file)}}">
				{{-- <iframe width="100%" height="100%" src="https://www.youtube.com/watch?v=wnHW6o8WMas"></iframe> --}}
				<span class="blog-slider-badge">{{$row->title}}</span>
				<div class="ms-info"></div>
				<div class="blog-slider-title">
					<span class="blog-slider-posted">{{ date('M  j, Y ',strtotime($row->created_at))}}</span>
					<h2><a href="#">{!!$row->description!!}</a></h2>
				</div>
			</div>
			@endforeach
			
			
			 
			
			
			
		</div>
	</div>
	<!-- End Master Slider -->

	<!--=== Container Part ===-->
	<div class="container margin-bottom-40">
		<div class="row">
			<!-- Main Content -->
			<div class="col-md-9">
				<!-- Tab v4 -->
				<div class="tab-v4 margin-bottom-40">
					<!-- Tab Heading -->
					<div class="tab-heading">
						<h2>Featured Advertising</h2>
						<ul class="nav nav-tabs" role="tablist">
							<li class="home active">
								<a href="#tab-v4-a1" role="tab" data-toggle="tab">Nepali</a>
							</li>
							<li>
								<a href="#tab-v4-a2" role="tab" data-toggle="tab">Indian</a>
							</li>

							<li>
								<a href="#tab-v4-a3" role="tab" data-toggle="tab">English</a>
							</li>
							
						</ul>
					</div>
					<!-- End Latest News -->

					<!-- Tab Content -->
					<div class="tab-content">
						<div class="tab-pane fade in active" id="tab-v4-a1">
							<div class="row">
								<div class="col-sm-7">
									<!-- Blog Grid -->

									@foreach($nepali->take(1) as $nepali1)
									<div class="blog-grid sm-margin-bottom-40">
										<img class="img-responsive" src="{{url('public/uploads/Advertising1/'.$nepali1->file)}}" alt="">
										<h3><a href="{{url('show',$nepali1->slug)}}">{{$nepali1->title}}</a></h3>
										<ul class="blog-grid-info">
											<li>Admin</li>
											<li>{{ date('M  j, Y ',strtotime($nepali1->created_at))}}</li>
											<li><a href="#"><i class="fa fa-comments"></i> 0</a></li>
										</ul>
										<p>{!! substr($nepali1->description, 0,350)!!} {{ strlen($nepali1->description) > 350 ? "..." : ""}}</p>
										<a class="r-more" href="{{url('show',$nepali1->slug)}}">Read More</a>
									</div>
									@endforeach
									<!-- End Blog Grid -->
								</div>

								<div class="col-sm-5">
									<!-- Blog Thumb -->
									@foreach($nepali as $row)
									<div class="blog-thumb margin-bottom-20">
										<div class="blog-thumb-hover">
											<img src="{{url('public/uploads/Advertising1/'.$row->file)}}" alt="">
											<a class="hover-grad" href="{{url('show',$row->slug)}}">{{-- <i class="fa fa-video-camera"></i> --}}</a>
										</div>
										<div class="blog-thumb-desc">
											<h3><a href="{{url('show',$row->slug)}}">{{$row->title}}</a></h3>
											<ul class="blog-thumb-info">
												<li>{{ date('M  j, Y ',strtotime($row->created_at))}}</li>
												<li><a href="#"><i class="fa fa-comments"></i> 0</a></li>
											</ul>
										</div>
									</div>
									@endforeach
									
								</div>
							</div><!--/end row-->
						</div>
						<div class="tab-pane fade" id="tab-v4-a2">
							<div class="row">
								<div class="col-sm-7">

									<!-- Blog Grid -->
									@foreach($indian->take(1) as $indian1)
									<div class="blog-grid sm-margin-bottom-40">
										<img class="img-responsive" src="{{url('public/uploads/Advertising1/'.$indian1->file)}}" alt="">
										<h3><a href="{{url('show',$indian1->slug)}}">{{$indian1->title}}</a></h3>
										<ul class="blog-grid-info">
											<li>Admin</li>
											<li>{{ date('M  j, Y ',strtotime($indian1->created_at))}}</li>
											<li><a href="#"><i class="fa fa-comments"></i> 0</a></li>
										</ul>
										<p>{!! substr($indian1->description, 0,350)!!} {{ strlen($indian1->description) > 350 ? "..." : ""}}</p>
										<a class="r-more" href="{{url('show',$indian1->slug)}}">Read More</a>
									</div>
									@endforeach
									<!-- End Blog Grid -->
								</div>

								<div class="col-sm-5">
									<!-- Blog Thumb -->
									@foreach($indian as $row)
									<div class="blog-thumb margin-bottom-20">
										<div class="blog-thumb-hover">
											<img src="{{url('public/uploads/Advertising1/'.$row->file)}}" alt="">
											<a class="hover-grad" href="{{url('show',$row->slug)}}">{{-- <i class="fa fa-video-camera"></i> --}}</a>
										</div>
										<div class="blog-thumb-desc">
											<h3><a href="{{url('show',$row->slug)}}">{{$row->title}}</a></h3>
											<ul class="blog-thumb-info">
												<li>{{ date('M  j, Y ',strtotime($row->created_at))}}</li>
												<li><a href="#"><i class="fa fa-comments"></i> 0</a></li>
											</ul>
										</div>
									</div>
									@endforeach
									
									<!-- End Blog Thumb -->
								</div>
							</div><!--/end row-->
						</div>

						<div class="tab-pane fade" id="tab-v4-a3">
							<div class="row">
								<div class="col-sm-7">
									<!-- Blog Grid -->
											@foreach($english->take(1) as $row)
									<div class="blog-grid sm-margin-bottom-40">
										<img class="img-responsive" src="{{url('public/uploads/Advertising1/'.$latestadvertising1->file)}}" alt="">
										<h3><a href="{{url('show',$latestadvertising1->slug)}}">{{$latestadvertising1->title}}</a></h3>
										<ul class="blog-grid-info">
											<li>Admin</li>
											<li>{{ date('M  j, Y ',strtotime($latestadvertising1->created_at))}}</li>
											<li><a href="#"><i class="fa fa-comments"></i> 0</a></li>
										</ul>
										<p>{!! substr($latestadvertising1->description, 0,350)!!} {{ strlen($latestadvertising1->description) > 350 ? "..." : ""}}</p>
										<a class="r-more" href="{{url('show',$latestadvertising1->slug)}}">Read More</a>
									</div>
									@endforeach
									<!-- End Blog Grid -->
								</div>

								<div class="col-sm-5">
									<!-- Blog Thumb -->
									@foreach($english as $row)
									<div class="blog-thumb margin-bottom-20">
										<div class="blog-thumb-hover">
											<img src="{{url('public/uploads/Advertising1/'.$row->file)}}" alt="">
											<a class="hover-grad" href="{{url('show',$row->slug)}}">{{-- <i class="fa fa-video-camera"></i> --}}</a>
										</div>
										<div class="blog-thumb-desc">
											<h3><a href="{{url('show',$row->slug)}}">{{$row->title}}</a></h3>
											<ul class="blog-thumb-info">
												<li>{{ date('M  j, Y ',strtotime($row->created_at))}}</li>
												<li><a href="#"><i class="fa fa-comments"></i> 0</a></li>
											</ul>
										</div>
									</div>
									@endforeach
									
									<!-- End Blog Thumb -->
								</div>
							</div><!--/end row-->
						</div>
		
					</div>
					<!-- End Tab Content -->
				</div>
				<!-- End Tab v4 -->


					<!-- Blog Carousel Heading -->
				<div class="blog-cars-heading">
					<h2>Latest Advertising</h2>
					<div class="owl-navigation">
						<div class="customNavigation">
							<a class="owl-btn prev-v3"><i class="fa fa-angle-left"></i></a>
							<a class="owl-btn next-v3"><i class="fa fa-angle-right"></i></a>
						</div>
					</div><!--/navigation-->
				</div>
				<!-- End Blog Carousel Heading -->

				<!-- Blog Carousel -->
				<div class="blog-carousel margin-bottom-50">
					<!-- Blog Grid -->
					@foreach($advertisingpopular as $row)
					<div class="item">
						<div class="row">
							<div class="col-sm-5 sm-margin-bottom-20">
								<img class="img-responsive" src="{{url('public/uploads/Advertising1/'.$row->file)}}" style="height: 250px; width:250px"; alt="{{$row->title}}">
							</div>
							<div class="col-sm-7">
								<div class="blog-grid">
									<h3><a href="{{url('show',$row->slug)}}">{{$row->title}}</a></h3>
									<ul class="blog-grid-info">
										
										<li>{{ date('M  j, Y ',strtotime($row->created_at))}}</li>
										<li><a href="#"><i class="fa fa-comments"></i> 0</a></li>
									</ul>
									<p>{!! substr($row->description, 0,350)!!} {{ strlen($row->description) > 350 ? "..." : ""}}</p>
									<a class="r-more" href="{{url('show',$row->slug)}}">Read More</a>
								</div>
							</div>
						</div>
					</div>
					@endforeach
					
				</div>
				<!-- End Blog Carousel -->
				

				

				<!-- Blog Grid -->
				<div class="margin-bottom-50">
					<h2 class="title-v4">Featured News</h2>
					<div class="row margin-bottom-50">
					@foreach($advertisingfeaturepost as $row)
						<div class="col-sm-6 sm-margin-bottom-50">
							<!-- Blog Grid -->
							<div class="blog-grid margin-bottom-40">
								<div class="carousel slide carousel-v2" id="portfolio-carousel">
									
									<div class="carousel-inner">
										<div class="item active">
											<img class="img-responsive" src="{{url('public/uploads/Advertising1',$row->file)}}"  alt="{{$row->title}}" style="height:120px; width: 250px;  ;display: block !important">
										</div>
										
									</div>
								</div>
								<h3><a href="{{url('show',$row->slug)}}">{!! substr($row->title, 0,20)!!} {{ strlen($row->title) > 20 ? "..." : ""}}</a></h3>
								<ul class="blog-grid-info">
									<li>Admin</li>
									<li>{{ date('M  j, Y ',strtotime($row->created_at))}}</li>
									<li><a href="#"><i class="fa fa-comments"></i> 0</a></li>
								</ul>
								<p>{!! substr($row->description, 0,350)!!} {{ strlen($row->description) > 350 ? "..." : ""}}</p>
								<a class="r-more" href="{{url('show',$row->slug)}}">Read More</a>
							</div>
						</div>
					@endforeach
					</div><!--/end row-->
					
				</div>
				<!-- End Blog Grid -->

				<!-- Blog Thumb v4 -->
				<div class="margin-bottom-50">
					<h2 class="title-v4">Weekly News</h2>
					<div class="row margin-bottom-50">
						
							


						@foreach($advertisingweekly as $row)
						<div class="col-sm-3 col-xs-6 sm-margin-bottom-30">
							<!-- Blog Thumb v4 -->
							<div class="blog-thumb-v4">
								<img class="img-responsive margin-bottom-10" src="{{asset('public/uploads/Advertising1/'.$row->file)}}" alt="{{$row->title}}" style="display: block !important; height: 150px; width:250px; ">
								<h3><a href="{{url('show',$row->slug)}}">{{$row->title}}</a></h3>
							</div>
							
						</div>
						@endforeach
					</div><!--/end row-->
					<div class="text-center">
						{{$advertisingweekly->links()}}
					</div>
				</div>
				<!-- End Blog Thumb v4 -->

				<!-- Tab v4 -->
				<div class="tab-v4 margin-bottom-50">
					<!-- Tab Heading -->
					<div class="tab-heading">
					<h2>Popular News</h2>
						<ul class="nav nav-tabs" role="tablist">
							<li class="home active">
								<a href="#tab-v4-b1" role="tab" data-toggle="tab">Advertising</a>
							</li>
							<li>
								<a href="#tab-v4-b2" role="tab" data-toggle="tab">Article</a>
							</li>
							
						</ul>
					</div>
					<!-- End Tab Heading -->

					<!-- Tab Content -->
					<div class="tab-content">
						<div class="tab-pane fade in active" id="tab-v4-b1">
							<div class="row">
								<div class="col-sm-7">
									<!-- Blog Grid -->
									<div class="blog-grid md-margin-bottom-40">
										<div class="blog-grid-grad">
											<img class="img-responsive" src="{{url('public/uploads/Advertising1',$advertisingpopular1->file)}}" alt="">
											<a href="{{url('show',$row->slug)}}">
												{{-- <i class="fa fa-video-camera"></i> --}}
											</a>
										</div>
										<h3><a href="{{url('show',$row->slug)}}">{{$advertisingpopular1->title}}</a></h3>
										<ul class="blog-grid-info">
											<li>Admin</li>
											<li>{{ date('M  j, Y ',strtotime($row->created_at))}}</li>
											<li><a href="#"><i class="fa fa-comments"></i> 0</a></li>
										</ul>
										<p>{!! substr($advertisingpopular1->description, 0,350)!!} {{ strlen($advertisingpopular1->description) > 350 ? "..." : ""}}</p>
										<a class="r-more" href="{{url('show',$row->slug)}}">Read More</a>
									</div>
									<!-- End Blog Grid -->
								</div>

								<div class="col-sm-5">
									<!-- Blog Thumb v2 -->
									@foreach($advertisingweekly as $row)
									<div class="blog-thumb-v2 margin-bottom-20">
										<div class="blog-thumb-grad">
											<img src="{{url('public/uploads/Advertising1',$row->file)}}" alt="">
											<a href="{{url('show',$row->slug)}}">
												{{-- <i class="fa fa-video-camera"></i> --}}
											</a>
										</div>
										<div class="blog-thumb-desc">
											<h3><a href="{{url('show',$row->slug)}}">{{$row->title}}</a></h3>
											<ul class="blog-thumb-info">
												<li>{{ date('M  j, Y ',strtotime($row->created_at))}}</li>
												<li><a href="#"><i class="fa fa-comments"></i> 0</a></li>
											</ul>
										</div>
									</div>
									@endforeach
									<!-- End Blog Thumb v2 -->

									
									<!-- End Blog Thumb v2 -->
								</div>
							</div><!--/end row-->
						</div>
						<div class="tab-pane fade" id="tab-v4-b2">
							<div class="row">
								<div class="col-sm-7">
									<!-- Blog Grid -->
									{{-- <div class="blog-grid md-margin-bottom-40">
										<div class="blog-grid-grad">
											<img class="img-responsive" src="{{url('public/uploads/Advertising1',$articlepopular1->file)}}" alt="">
											<a href="{{url('article/show',$articlepopular1->slug)}}">
												
											</a>
										</div>
										<h3><a href="{{url('article/show',$articlepopular1->slug)}}">{{$articlepopular1->title}}</a></h3>
										<ul class="blog-grid-info">
											<li>Admin</li>
											<li>{{ date('M  j, Y ',strtotime($articlepopular1->created_at))}}</li>
											<li><a href="#"><i class="fa fa-comments"></i> 0</a></li>
										</ul>
										<p>{{$articlepopular1->description}}</p>
										<a class="r-more" href="{{url('article/show',$articlepopular1->slug)}}">Read More</a>
									</div> --}}
									<!-- End Blog Grid -->
								</div>

								<div class="col-sm-5">
									<!-- Blog Thumb v2 -->
									@foreach($articlepopular as $row)
									<div class="blog-thumb-v2 margin-bottom-20">
										<div class="blog-thumb-grad">
											<img src="{{url('public/uploads/Advertising1',$row->file)}}" alt="">
											<a href="blog_single.html">
												{{-- <i class="fa fa-video-camera"></i> --}}
											</a>
										</div>
										<div class="blog-thumb-desc">
											<h3><a href="{{url('article/show',$row->slug)}}">{{$row->title}}</a></h3>
											<ul class="blog-thumb-info">
												<li>{{ date('M  j, Y ',strtotime($row->created_at))}}</li>
												<li><a href="#"><i class="fa fa-comments"></i> 0</a></li>
											</ul>
										</div>
									</div>
									@endforeach
									
								</div>
							</div><!--/end row-->
						</div>
				
					</div>
					<!-- End Tab Content -->
				</div>
				<!-- End Tab v4 -->

				<!-- Blog Grid -->
				<div class="margin-bottom-50">
					<h2 class="title-v4">Monthly News</h2>

					<!-- Blog Grid -->
					<div class="row margin-bottom-50">
						@foreach($advertisingmonthly as $advertisingmonth)
							@foreach($advertisingmonth as $row)
						<div class="col-sm-6 sm-margin-bottom-50">
							
							<div class="blog-grid">
								<img class="img-responsive" src="{{url('public/uploads/Advertising1/'.$row->file)}}" style="height: 250px; width:250px";  alt="{{$row->title}}">
								<h3><a href="{{url('show',$row->slug)}}">{!! substr($row->title, 0,25)!!} {{ strlen($row->title) > 25 ? "..." : ""}}</a></h3>
								<ul class="blog-grid-info">
									<li>Admin</li>
									<li>{{ date('M  j, Y ',strtotime($row->created_at))}}</li>
									<li><a href="#"><i class="fa fa-comments"></i> 0</a></li>
								</ul>
							</div>
							
						</div>
						@endforeach
						@endforeach
						
					</div><!--/end row-->
					<!-- End Blog Grid -->

					
				</div>
				<!-- End Blog Grid -->

				<!-- Pager v4
				<ul class="pager pager-v4 md-margin-bottom-50">
					<li class="previous"><a class="rounded-3x" href="#">&larr; Older</a></li>
					<li class="page-amount">1 of 7</li>
					<li class="next"><a class="rounded-3x" href="#">Newer &rarr;</a></li>
				</ul>
				End Pager v4 -->
			</div>
			<!-- End Main Content -->

			<!-- Right Sidebar -->
			<div class="col-md-3">
				<!-- Blog Thumb v3 -->
				<div class="margin-bottom-50">
					<h2 class="title-v4">Blog &amp; Comments</h2>

					<div class="blog-thumb-v3">
						@foreach($article as $row)
						<small><a href="#">Admin</a></small>
						<h3><a href="#">{{$row->title}}</a></h3>
						@endforeach
					</div>

					

					

					
					
				</div>
				<!-- End Blog Thumb v3 -->

				<!-- Social Shares -->
				<div class="margin-bottom-50">
					<h2 class="title-v4">Social</h2>
					<ul class="blog-social-shares">
						<li>
							<i class="rounded-x fb fa fa-facebook"></i>
							<a class="rounded-3x" href="#">Like</a>
							<span class="counter">31,702</span>
						</li>
						<li>
							<i class="rounded-x tw fa fa-twitter"></i>
							<a class="rounded-3x" href="#">Follow Us</a>
							<span class="counter">164,290</span>
						</li>
						<li>
							<i class="rounded-x gp fa fa-google-plus"></i>
							<a class="rounded-3x" href="#">Add to circle</a>
							<span class="counter">5,425,764</span>
						</li>
					</ul>
				</div>
				<!-- End Social Shares -->

				<!-- Blog Thumb v2 -->
				<div class="margin-bottom-50">
					<h2 class="title-v4">Recent News</h2>
					@foreach($recentnews as $row)
					<div class="blog-thumb blog-thumb-circle margin-bottom-15">
						<div class="blog-thumb-hover">
							<img class="rounded-x" src="{{url('public/uploads/Article',$row->file)}}" alt="">
							<a class="hover-grad" href="{{url('article/show',$row->slug)}}"><i class="fa fa-link"></i></a>
						</div>
						<div class="blog-thumb-desc">
							<h3><a href="{{url('article/show',$row->slug)}}">{{$row->title}}</a></h3>
							<ul class="blog-thumb-info">
								<li>{{ date('M  j, Y ',strtotime($row->created_at))}}</li>
								<li><a href="#"><i class="fa fa-comments"></i> 0</a></li>
							</ul>
						</div>
					</div>
					@endforeach

					

					
					
				</div>
				<!-- End Blog Thumb v2 -->

				<!-- Tab v5 -->
				<div class="tab-v5 margin-bottom-50">
					<ul class="nav nav-tabs" role="tablist">
						<li class="home active">
							<a href="#tab-v5-a1" role="tab" data-toggle="tab">Hi-Tech</a>
						</li>
						<li>
							<a href="#tab-v5-a2" role="tab" data-toggle="tab">Other News</a>
						</li>
					</ul>

					<div class="tab-content">
						<div class="tab-pane in active" id="tab-v5-a1">
							<!-- Blog Grid -->
							<div class="blog-grid margin-bottom-30">
								<h3><a href="blog_single.html">Audio Recorder AR-T7 explained</a></h3>
								<ul class="blog-grid-info">
									<li>Mar 6, 2015</li>
									<li><a href="#"><i class="fa fa-comments"></i> 0</a></li>
								</ul>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec imperdiet sed eros sed tincidunt.</p>
							</div>
							<!-- End Blog Grid -->

							<!-- Blog Thumb -->
							<div class="blog-thumb margin-bottom-20">
								<div class="blog-thumb-hover">
									<img src="assets/img/blog/img44.jpg" alt="">
									<a class="hover-grad" href="blog_single.html"><i class="fa fa-video-camera"></i></a>
								</div>
								<div class="blog-thumb-desc">
									<h3><a href="blog_single.html">Apple iPad review</a></h3>
								</div>
							</div>
							<!-- End Blog Thumb -->

							<!-- Blog Thumb -->
							<div class="blog-thumb">
								<div class="blog-thumb-hover">
									<img src="assets/img/blog/img8.jpg" alt="">
									<a class="hover-grad" href="blog_single.html"><i class="fa fa-photo"></i></a>
								</div>
								<div class="blog-thumb-desc">
									<h3><a href="blog_single.html">The new MacBook Air Impressions!</a></h3>
								</div>
							</div>
							<!-- End Blog Thumb -->
						</div>
						<div class="tab-pane" id="tab-v5-a2">
							<div class="blog-thumb-v3">
								<small>Mar 6, 2015</small>
								<h3><a href="#">Cameron's silence on defence is shameful</a></h3>
							</div>

							<hr class="hr-xs">

							<div class="blog-thumb-v3">
								<small>Mar 7, 2015</small>
								<h3><a href="#">Architects plan to stop skyscrapers from blocking out sunlight</a></h3>
							</div>

							<hr class="hr-xs">

							<div class="blog-thumb-v3">
								<small>Mar 9, 2015</small>
								<h3><a href="#">Fashion's first selfies: It was a 16th-century German accountant who started the trend for style blogging</a></h3>
							</div>

							<hr class="hr-xs">

							<div class="blog-thumb-v3">
								<small>Mar 12, 2015</small>
								<h3><a href="#">How to run a country: A 10 point manifesto for leaders who stand – and want to deliver</a></h3>
							</div>

							<hr class="hr-xs">

							<div class="blog-thumb-v3">
								<small>Mar 23, 2015</small>
								<h3><a href="#">Controversial plan to test new primary school pupils infuriates teachers</a></h3>
							</div>
						</div>
					</div>
				</div>
				<!-- End Tab v5 -->

				<!-- Tags v3 -->
				<div class="margin-bottom-50">
					<h2 class="title-v4">Tags</h2>

					<ul class="list-inline tags-v3">
						<li><a class="rounded-3x" href="#">Web Design</a></li>
						<li><a class="rounded-3x" href="#">Economy</a></li>
						<li><a class="rounded-3x" href="#">Sport</a></li>
						<li><a class="rounded-3x" href="#">Marketing</a></li>
						<li><a class="rounded-3x" href="#">Books</a></li>
						<li><a class="rounded-3x" href="#">Elections</a></li>
						<li><a class="rounded-3x" href="#">Flickr</a></li>
						<li><a class="rounded-3x" href="#">Politics</a></li>
						<li><a class="rounded-3x" href="#">Marketing</a></li>
						<li><a class="rounded-3x" href="#">Web Hosting</a></li>
						<li><a class="rounded-3x" href="#">Art &amp; Design</a></li>
					</ul>
				</div>
				<!-- End Tags v3 -->

				<!-- Blog Carousel Heading -->
				<div class="blog-cars-heading">
					<h2>Popular Video</h2>
					<div class="owl-navigation">
						<div class="customNavigation">
							<a class="owl-btn prev-v4"><i class="fa fa-angle-left"></i></a>
							<a class="owl-btn next-v4"><i class="fa fa-angle-right"></i></a>
						</div>
					</div><!--/navigation-->
				</div>
				<!-- End Blog Carousel Heading -->

				<!-- Blog Carousel -->
				<div class="blog-carousel-v2 margin-bottom-50">
					<!-- Blog Video -->
					<div class="item">
						<div class="blog-video">
							<img class="full-width" src="{{url('public/marketing/img/video/img-video2.jpg')}}" alt="">
							<span class="category-badge">Holiday</span>
							<span class="date-badge">Mar 6, 2015</span>
							<div class="center-wrap">
								<span class="center-alignCenter">
									{{-- <span class="center-body">
										<a href="{!! videoforindex()->description !!}" class=" popup-videos" title="At World's end">
											<span><img class="video-play-btn" src="{{asset('public/marketing/img/icons/video-play.png')}}" alt=""></span>
										</a>
									</span>
 --}}
                
                 


								</span>
							</div><!--/end center wrap-->
							<h4><a href="#">Most Beautiful Places</a></h4>
						</div>
					</div>
					<!-- End Blog Video -->

					<!-- Blog Video -->
					<div class="item">
						<div class="blog-video">
							<img class="full-width" src="assets/img/video/img-video1.jpg" alt="">
							<span class="category-badge">Science</span>
							<span class="date-badge">Mar 6, 2015</span>
							<div class="center-wrap">
								<span class="center-alignCenter">
									<span class="center-body">
										<a href="http://player.vimeo.com/video/47911018" class="fbox-modal fancybox.iframe" title="Existance a timeplase project">
											<span><img class="video-play-btn" src="assets/img/icons/video-play.png" alt=""></span>
										</a>
									</span>
								</span>
							</div><!--/end center wrap-->
							<h4><a href="#">Existance a timeplase project</a></h4>
						</div>
					</div>
					<!-- End Blog Video -->

					<!-- Blog Video -->
					<div class="item">
						<div class="blog-video">
							<img class="full-width" src="assets/img/video/img-video3.jpg" alt="">
							<span class="category-badge">Travel</span>
							<span class="date-badge">Mar 6, 2015</span>
							<div class="center-wrap">
								{{-- <span class="center-alignCenter">
									<span class="center-body">
										<a href="{!! videoforindex()->description !!}" title="Who are the 10 greatest living athletes in the UK?">
											<span><img class="video-play-btn" src="assets/img/icons/video-play.png" alt=""></span>
										</a>
									</span>
								</span> --}}
							</div><!--/end center wrap-->
							<h4><a href="#">Who are the 10 greatest living athletes in the UK?</a></h4>
						</div>
					</div>
					<!-- End Blog Video -->
				</div>
				<!-- End Blog Carousel -->

				<!-- Twitter Posts -->
				<div class="margin-bottom-50">
					<h2 class="title-v4">Twitter Posts</h2>

					<ul class="twitter-posts">
						<li>
							<img class="rounded-x" src="assets/img/thumb/img-thumb5.jpg" alt="">
							<div class="twitter-posts-in">
								<strong>Dr.Cafee</strong>
								<span><a href="#">@DrCafee</a></span>
								<span>4h</span>
								<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
								<a class="link" href="#">http://bit.ly/1c0UN3Y</a>
							</div>
						</li>
						<li>
							<img class="rounded-x" src="assets/img/thumb/img-thumb4.jpg" alt="">
							<div class="twitter-posts-in">
								<strong>Jessi</strong>
								<span><a href="#">@Jessi</a></span>
								<span>5m</span>
								<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
								<a class="link" href="#">http://bit.ly/1c0UN3Y</a>
							</div>
						</li>
						<li>
							<img class="rounded-x" src="assets/img/thumb/img-thumb6.jpg" alt="">
							<div class="twitter-posts-in">
								<strong>PhotoStudio</strong>
								<span><a href="#">@PS</a></span>
								<span>7h</span>
								<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
								<a class="link" href="#">http://bit.ly/1c0UN3Y</a>
							</div>
						</li>
						<li>
							<img class="rounded-x" src="assets/img/thumb/img-thumb7.jpg" alt="">
							<div class="twitter-posts-in">
								<strong>Wrapbootstrap</strong>
								<span><a href="#">@Wrapbootstrap</a></span>
								<span>25m</span>
								<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
								<a class="link" href="#">http://bit.ly/1c0UN3Y</a>
							</div>
						</li>
					</ul>
				</div>
				<!-- End Twitter Posts -->
			</div>
			<!-- End Right Sidebar -->
		</div>
	</div>
	<!--=== End Container Part ===-->

	<!--=== Footer v8 ===-->
	
@stop